var numero1 =10;
var numero2 =20;

function sumar() {
    var resultado = numero1 + numero2;
    console.log (resultado);
    return resultado;
}

function restar() {
    var resultado = numero1 - numero2;
    console.log (resultado);
    return resultado;
}

function multiplicar() {
    var resultado = numero1 * numero2;
    console.log (resultado);
    return resultado;
}

function dividir() {
    var resultado = numero1 / numero2;
    console.log (resultado);
    return resultado;
}