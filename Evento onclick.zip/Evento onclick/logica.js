function login(element){
    document.getElementById("demo").innerHTML = "Logout"
}

function like(){
    alert("ninja was liked");
}

function remove(){
    const element = document.getElementById ("remover");
    element.remove ();
}